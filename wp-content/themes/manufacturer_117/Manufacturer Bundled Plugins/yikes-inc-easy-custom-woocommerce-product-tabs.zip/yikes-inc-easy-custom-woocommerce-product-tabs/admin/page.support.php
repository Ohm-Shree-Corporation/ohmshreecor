<div class="wrap woo-ct-admin-page-wrap">

	<!-- Title -->
	<h1>
		<span class="dashicons dashicons-exerpt-view"></span> 
		<?php _e( 'Custom Product Tabs for WooCommerce | Support', 'yikes-inc-easy-custom-woocommerce-product-tabs' ); ?>
	</h1>

	<!-- Free Support-content Hook -->
	<?php do_action( 'yikes-woo-support-page-free' ); ?>

	<!-- Pro Support-content Hook -->
	<?php do_action( 'yikes-woo-support-page-pro' ); ?>

</div>